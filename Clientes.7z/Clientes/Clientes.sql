
/* Drop Tables */

DROP TABLE IF EXISTS inv_ventas_detalles;
DROP TABLE IF EXISTS inv_ventas;
DROP TABLE IF EXISTS com_clientes;




/* Create Tables */

CREATE TABLE com_clientes
(
	cli_id_cliente varchar NOT NULL,
	-- Nombres de los clientes
	-- 
	cli_nombre varchar,
	-- Primer apellido del cliente
	-- 
	cli_apellido1 varchar,
	-- Segundo apellido del cliente
	cli_apellido2 varchar,
	-- Contacto(correo del cliente)
	-- 
	cli_correo varchar,
	-- telefono del cliente n°1
	cli_telefono1 varchar,
	-- Fecha de nacimiento en los datos del cliente}
	-- 
	cli_fecha_nacimiento date,
	-- Fecha de registro del cliente
	cli_fecha_alta timestamp,
	-- Fecha de modificacion de los datos del cliente
	cli_fecha_modificacion timestamp,
	PRIMARY KEY (cli_id_cliente)
) WITHOUT OIDS;


CREATE TABLE inv_ventas
(
	-- Numero identificador unico de venta
	ven_id_venta serial NOT NULL,
	ven_id_cliente varchar NOT NULL,
	ven_fecha_venta timestamp,
	-- Monto sin impuesto
	-- 
	ven_monto_subtotal numeric(30,2),
	-- Monto con impuesto
	ven_monto_total decimal(30,2),
	PRIMARY KEY (ven_id_venta)
) WITHOUT OIDS;


CREATE TABLE inv_ventas_detalles
(
	-- Numero unico del detalle
	ven_det_id serial NOT NULL,
	-- Numero identificador unico de venta
	ven_id_venta int NOT NULL,
	PRIMARY KEY (ven_det_id)
) WITHOUT OIDS;



/* Create Foreign Keys */

ALTER TABLE inv_ventas
	ADD CONSTRAINT r_clientes_ventas FOREIGN KEY (ven_id_cliente)
	REFERENCES com_clientes (cli_id_cliente)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE inv_ventas_detalles
	ADD CONSTRAINT r_ventas_ventasdetalles FOREIGN KEY (ven_id_venta)
	REFERENCES inv_ventas (ven_id_venta)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;



/* Comments */

COMMENT ON COLUMN com_clientes.cli_nombre IS 'Nombres de los clientes
';
COMMENT ON COLUMN com_clientes.cli_apellido1 IS 'Primer apellido del cliente
';
COMMENT ON COLUMN com_clientes.cli_apellido2 IS 'Segundo apellido del cliente';
COMMENT ON COLUMN com_clientes.cli_correo IS 'Contacto(correo del cliente)
';
COMMENT ON COLUMN com_clientes.cli_telefono1 IS 'telefono del cliente n°1';
COMMENT ON COLUMN com_clientes.cli_fecha_nacimiento IS 'Fecha de nacimiento en los datos del cliente}
';
COMMENT ON COLUMN com_clientes.cli_fecha_alta IS 'Fecha de registro del cliente';
COMMENT ON COLUMN com_clientes.cli_fecha_modificacion IS 'Fecha de modificacion de los datos del cliente';
COMMENT ON COLUMN inv_ventas.ven_id_venta IS 'Numero identificador unico de venta';
COMMENT ON COLUMN inv_ventas.ven_monto_subtotal IS 'Monto sin impuesto
';
COMMENT ON COLUMN inv_ventas.ven_monto_total IS 'Monto con impuesto';
COMMENT ON COLUMN inv_ventas_detalles.ven_det_id IS 'Numero unico del detalle';
COMMENT ON COLUMN inv_ventas_detalles.ven_id_venta IS 'Numero identificador unico de venta';



